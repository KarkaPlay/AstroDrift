#if UNITY_EDITOR
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

/// <summary>
/// Редакторная утилита (GDD_DeathScreen_v3 §2): собирает DeathPanel как ПРЕФАБ —
/// дом-паттерн StartPanel (MenuPrefabBuilder + связанный инстанс в сцене).
/// Строит всё С НУЛЯ (не зависит от состояния сцены) и перезаписывает ассет,
/// поэтому повторный прогон даёт тот же результат.
/// Спрайты берутся по пути (§2.49: Texture Type = Sprite, Sprite Mode = Single),
/// а НЕ из контейнера PrefabBuilderSprites — ассеты меню/LevelUp не затрагиваются.
/// Шрифты — TypographyConfig (как MenuPrefabBuilder), роли — TypeRoleTag (§13).
///   Assets/Prefabs/Death/DeathPanel.prefab — экран смерти целиком (инстанс в сцене)
/// Меню: AstroDrift → Build Death Prefab. После сборки — AstroDrift → Setup Scene UI.
/// </summary>
public static class DeathPrefabBuilder
{
    private const string Folder = "Assets/Prefabs/Death";
    private const string PanelPath = Folder + "/DeathPanel.prefab";

    private const float PanelW = 1080f, PanelH = 1920f;

    // Пути из таблицы §2 (колонка «Спрайт»)
    private const string SkullPath = "Assets/New UI/Skull.png";
    private const string ScorePanelPath = "Assets/New UI/DeathScore Panel.png";
    private const string ContinuePath = "Assets/New UI/Death Continue Ad.png";
    private const string HomePath = "Assets/New UI/Home Button.png";
    private const string BarSpritePath = "Assets/New UI/Generated/RoundedBar.png";

    [MenuItem("AstroDrift/Build Death Prefab")]
    public static void BuildAll()
    {
        var log = new System.Text.StringBuilder();

        var cfg = PrefabBuilderAssets.LoadContainer<TypographyConfig>("Assets/Resources/TypographyConfig.asset", "DeathPrefabBuilder");
        if (cfg == null) return;
        if (cfg.ResolveFont(TypographyStyles.Body, null) == null) log.Append("ВНИМАНИЕ: TypographyConfig пуст (шрифт — fallback); ");

        // Спрайты обязательны (§2): без них ломается и вёрстка, и критерий приёмки про бар.
        var skull = LoadSprite(SkullPath);
        var scorePanel = LoadSprite(ScorePanelPath);
        var continueBg = LoadSprite(ContinuePath);
        var homeBg = LoadSprite(HomePath);
        var barSprite = LoadSprite(BarSpritePath);
        if (!RequireSprites(log, skull, scorePanel, continueBg, homeBg, barSprite)) return;

        EnsureFolders();

        var panel = new GameObject("DeathPanel", typeof(RectTransform), typeof(Image), typeof(CanvasGroup));
        var prt = panel.GetComponent<RectTransform>();
        prt.anchorMin = prt.anchorMax = prt.pivot = new Vector2(0.5f, 0.5f);
        prt.sizeDelta = new Vector2(PanelW, PanelH);
        var pImg = panel.GetComponent<Image>();
        pImg.color = new Color(0f, 0f, 0f, 0f); // прозрачный фон — плашки нет
        pImg.raycastTarget = false;
        // §8: панель гасится целиком CanvasGroup'ом; стартовое состояние — скрыта
        // (в сцене AstroDriftSceneSetup доводит до SetActive(false)).
        var pcg = panel.GetComponent<CanvasGroup>();
        pcg.alpha = 0f; pcg.blocksRaycasts = false; pcg.interactable = false;

        // 1. DeathScrim — ПЕРВЫЙ ребёнок (нижний слой), raycastTarget = false (§2)
        var scrim = NewRect(panel.transform, "DeathScrim");
        SetRect(scrim, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1680f, 2520f));
        var scrimImg = scrim.gameObject.AddComponent<Image>();
        scrimImg.color = new Color(0f, 0f, 0f, 0.7f); // 0.7 глушит bloom-остаток мира
        scrimImg.raycastTarget = false;

        // 2. DeathSkull (0, 690) 200×200
        var skullRt = NewImage(panel.transform, "DeathSkull", skull, new Vector2(0f, 690f), new Vector2(200f, 200f));

        // 3. DeathTitle — Title 72, ключ death_title
        var title = NewTmp(panel.transform, "DeathTitle", cfg, TypographyStyles.Title, 72f,
            Palette.ScoreText, TextAlignmentOptions.Center, new Vector2(0f, 500f), new Vector2(900f, 110f));
        AddLocalize(title, "death_title");

        // 4. DeathSubtitle — Secondary 30, ключ death_subtitle
        var subtitle = NewTmp(panel.transform, "DeathSubtitle", cfg, TypographyStyles.Secondary, 30f,
            Palette.SecondaryText, TextAlignmentOptions.Center, new Vector2(0f, 420f), new Vector2(900f, 60f));
        AddLocalize(subtitle, "death_subtitle");

        // 5. DeathScorePanel — спрайт-плашка с двумя парами «подпись + число» (§1)
        var scorePanelRt = NewImage(panel.transform, "DeathScorePanel", scorePanel, new Vector2(0f, 60f), new Vector2(800f, 478f));
        var bestLabel = NewTmp(scorePanelRt, "DeathBestLabel", cfg, TypographyStyles.Secondary, 30f,
            Palette.SecondaryText, TextAlignmentOptions.Center, new Vector2(0f, 150f), new Vector2(700f, 50f));
        AddLocalize(bestLabel, "best_label");
        // Числа — ключ best_value (динамика: Arguments ставит GameUI перед показом §10)
        var bestValue = NewTmp(scorePanelRt, "DeathBest", cfg, TypographyStyles.DeathScore, 64f,
            Palette.ScoreText, TextAlignmentOptions.Center, new Vector2(0f, 75f), new Vector2(700f, 80f));
        AddLocalize(bestValue, "best_value");
        var runLabel = NewTmp(scorePanelRt, "DeathRunLabel", cfg, TypographyStyles.Secondary, 30f,
            Palette.SecondaryText, TextAlignmentOptions.Center, new Vector2(0f, -60f), new Vector2(700f, 50f));
        AddLocalize(runLabel, "score_label");
        var scoreValue = NewTmp(scorePanelRt, "DeathScore", cfg, TypographyStyles.DeathScore, 88f,
            Palette.ScoreText, TextAlignmentOptions.Center, new Vector2(0f, -140f), new Vector2(700f, 110f));
        AddLocalize(scoreValue, "best_value");

        // 6. Btn_Continue — спрайт-кнопка с CanvasGroup: истечение оффера гасит блок ЦЕЛИКОМ (§2)
        var cont = new GameObject("Btn_Continue", typeof(RectTransform), typeof(Image), typeof(Button), typeof(CanvasGroup));
        cont.transform.SetParent(panel.transform, false);
        SetRect((RectTransform)cont.transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, -400f), new Vector2(860f, 285f));
        var contImg = cont.GetComponent<Image>();
        contImg.sprite = continueBg;
        contImg.preserveAspect = false;
        contImg.raycastTarget = true; // тапы ловит только сам Image кнопки (§2)
        var contBtn = cont.GetComponent<Button>();
        contBtn.targetGraphic = contImg;
        var contCg = cont.GetComponent<CanvasGroup>();
        contCg.alpha = 1f; contCg.blocksRaycasts = true; contCg.interactable = true;

        var ctaText = NewTmp(cont.transform, "ContinueText", cfg, TypographyStyles.Cta, 40f,
            Palette.UiAccent, TextAlignmentOptions.Center, new Vector2(0f, 70f), new Vector2(800f, 60f));
        AddLocalize(ctaText, "continue_cta");
        var caption = NewTmp(cont.transform, "ContinueCaption", cfg, TypographyStyles.Secondary, 22f,
            Palette.SecondaryText, TextAlignmentOptions.Center, new Vector2(0f, 18f), new Vector2(800f, 40f));
        AddLocalize(caption, "continue_caption");

        var timerBg = NewRect(cont.transform, "ContinueTimerBg");
        SetRect(timerBg, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, -85f), new Vector2(520f, 16f));
        var timerBgImg = timerBg.gameObject.AddComponent<Image>();
        timerBgImg.color = new Color(0f, 0f, 0f, 0.25f);
        timerBgImg.raycastTarget = false;

        // Заливка: ОДИН механизм — Filled/Horizontal/Left, якоря растянуты (UiProgressBar.Set).
        // Спрайт обязателен: без него Filled игнорируется и бар всегда полный (UiProgressBar §19).
        var timerFill = NewRect(timerBg, "ContinueTimerFill");
        timerFill.anchorMin = Vector2.zero;
        timerFill.anchorMax = Vector2.one;
        timerFill.offsetMin = Vector2.zero;
        timerFill.offsetMax = Vector2.zero;
        var timerFillImg = timerFill.gameObject.AddComponent<Image>();
        timerFillImg.sprite = barSprite;
        timerFillImg.color = Palette.XpBar; // §1: цвет как у XP-бара, единственное золото — CTA
        timerFillImg.raycastTarget = false;
        timerFillImg.type = Image.Type.Filled;
        timerFillImg.fillMethod = Image.FillMethod.Horizontal;
        timerFillImg.fillOrigin = (int)Image.OriginHorizontal.Left;
        timerFillImg.fillAmount = 1f; // §3: бар ВСЕГДА стартует полным

        // 7. Btn_Home — Image-спрайт + Button + HomeText (был текстовой кнопкой, §6)
        var home = new GameObject("Btn_Home", typeof(RectTransform), typeof(Image), typeof(Button), typeof(CanvasGroup));
        home.transform.SetParent(panel.transform, false);
        SetRect((RectTransform)home.transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, -760f), new Vector2(420f, 168f));
        var homeImg = home.GetComponent<Image>();
        homeImg.sprite = homeBg;
        homeImg.preserveAspect = false;
        homeImg.raycastTarget = true;
        var homeBtn = home.GetComponent<Button>();
        homeBtn.targetGraphic = homeImg;
        var homeCg = home.GetComponent<CanvasGroup>();
        homeCg.alpha = 1f; homeCg.blocksRaycasts = true; homeCg.interactable = true;

        var homeText = NewTmp(home.transform, "HomeText", cfg, TypographyStyles.Button, 34f,
            Palette.ScoreText, TextAlignmentOptions.Center, Vector2.zero, new Vector2(380f, 60f));
        AddLocalize(homeText, "home_to_menu"); // ключ home НЕ трогаем — он шарится с PausePanel

        PrefabUtility.SaveAsPrefabAsset(panel, PanelPath);
        Object.DestroyImmediate(panel);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("AstroDrift DeathPrefab: DeathPanel OK (" + PanelPath + "). " + log);
    }

    // ————————————— хелперы —————————————

    /// <summary>Спрайт по пути. Штатный случай — Sprite Mode = Single (§2);
    /// если ассет импортирован как Multiple (авто-слайс «<имя>_0»), берём единственный
    /// саб-спрайт, чтобы префаб не остался без картинки молча.</summary>
    private static Sprite LoadSprite(string path)
    {
        var sprite = AssetDatabase.LoadAssetAtPath<Sprite>(path);
        if (sprite != null) return sprite;

        foreach (var a in AssetDatabase.LoadAllAssetsAtPath(path))
        {
            sprite = a as Sprite;
            if (sprite == null) continue;
            Debug.LogWarning("AstroDrift DeathPrefab: " + path + " импортирован как Multiple — взят первый саб-спрайт. " +
                             "Для штатного пути поставьте Texture Type = Sprite (2D and UI), Sprite Mode = Single (§2).");
            return sprite;
        }
        return null;
    }

    private static bool RequireSprites(System.Text.StringBuilder log, Sprite skull, Sprite scorePanel,
        Sprite continueBg, Sprite homeBg, Sprite barSprite)
    {
        var missing = new System.Text.StringBuilder();
        int count = 0;
        void Check(Sprite s, string path)
        {
            if (s != null) return;
            if (count++ > 0) missing.Append(", ");
            missing.Append(path);
        }
        Check(skull, SkullPath);
        Check(scorePanel, ScorePanelPath);
        Check(continueBg, ContinuePath);
        Check(homeBg, HomePath);
        Check(barSprite, BarSpritePath);

        if (count == 0) return true;
        Debug.LogError("AstroDrift DeathPrefab: не найдено " + count + " спрайт(ов) — префаб не записан: " + missing
            + ". Импорт: Texture Type = Sprite (2D and UI), Sprite Mode = Single (§2).");
        log.Append("СПРАЙТЫ НЕ НАЙДЕНЫ; ");
        return false;
    }

    private static void EnsureFolders()
    {
        if (!AssetDatabase.IsValidFolder("Assets/Prefabs")) AssetDatabase.CreateFolder("Assets", "Prefabs");
        if (!AssetDatabase.IsValidFolder(Folder)) AssetDatabase.CreateFolder("Assets/Prefabs", "Death");
    }

    private static RectTransform NewRect(Transform parent, string name)
    {
        var go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        return go.GetComponent<RectTransform>();
    }

    private static void SetRect(RectTransform rt, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size)
    {
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.pivot = pivot;
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
    }

    private static RectTransform NewImage(Transform parent, string name, Sprite sprite, Vector2 pos, Vector2 size)
    {
        var rt = NewRect(parent, name);
        SetRect(rt, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), pos, size);
        var img = rt.gameObject.AddComponent<Image>();
        img.sprite = sprite;
        img.color = Color.white;
        img.preserveAspect = false;
        img.raycastTarget = false;
        return rt;
    }

    /// <summary>TMP-нода с запечённым шрифтом стиля и тегом TypeRoleTag (§13):
    /// смена локали применяет шрифт через TypeRoleApplier, ручных применений в GameUI нет.</summary>
    private static TextMeshProUGUI NewTmp(Transform parent, string name, TypographyConfig cfg, string styleId,
        float size, Color color, TextAlignmentOptions align, Vector2 pos, Vector2 size2)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        SetRect(rt, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), pos, size2);
        var tmp = go.GetComponent<TextMeshProUGUI>();
        tmp.text = "";
        var font = Resolve(cfg, styleId);
        if (font != null) tmp.font = font;
        tmp.fontSize = size;
        tmp.color = color;
        tmp.alignment = align;
        tmp.textWrappingMode = TextWrappingModes.NoWrap;
        tmp.raycastTarget = false;
        AddRole(tmp, styleId);
        return tmp;
    }

    /// <summary>Шрифт стиля (базовый, без локали) — та же точка, что у Typography (§13).</summary>
    private static TMP_FontAsset Resolve(TypographyConfig cfg, string styleId)
    {
        return cfg != null ? cfg.ResolveFont(styleId, null) : null;
    }

    /// <summary>LocalizeStringEvent на ноде + persistent-listener TMP.text
    /// (та же схема, что LocalizeComponent_TMP.SetupForLocalization).</summary>
    private static void AddLocalize(TextMeshProUGUI tmp, string key)
    {
        var lse = tmp.gameObject.AddComponent<LocalizeStringEvent>();
        lse.StringReference.TableReference = "GameTexts";
        lse.StringReference.TableEntryReference = key;
        var setter = tmp.GetType().GetProperty("text").GetSetMethod();
        var handler = System.Delegate.CreateDelegate(typeof(UnityEngine.Events.UnityAction<string>), tmp, setter)
            as UnityEngine.Events.UnityAction<string>;
        UnityEditor.Events.UnityEventTools.AddPersistentListener(lse.OnUpdateString, handler);
        lse.OnUpdateString.SetPersistentListenerState(0, UnityEngine.Events.UnityEventCallState.EditorAndRuntime);
    }

    /// <summary>Тег шрифтового стиля. Пустой id = тег бездействует (шрифт ноды сохраняется).</summary>
    private static void AddRole(TextMeshProUGUI tmp, string styleId)
    {
        var tag = tmp.gameObject.AddComponent<TypeRoleTag>();
        var so = new SerializedObject(tag);
        so.FindProperty("styleId").stringValue = styleId;
        so.ApplyModifiedPropertiesWithoutUndo();
    }
}
#endif
