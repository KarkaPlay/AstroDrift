#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Одноразовая миграция типографики: legacy enum-поле TypeRoleTag.role → string styleId,
/// плюс засев TypographyConfig.styles по ФАКТИЧЕСКИМ шрифтам нод (без визуальных изменений).
///
/// Поле `role` больше не существует в TypeRoleTag, поэтому Unity его не десериализует —
/// правка идёт по сериализованным данным (YAML) префабов и сцен, а не через SerializedObject.
/// Префабы владельца (DeathPanel) НЕ пересобираются: только строка `role: N` → `styleId: ...`.
///
/// Идемпотентна: повторный прогон не находит `role:` внутри блоков TypeRoleTag и ничего не меняет.
/// Меню: AstroDrift → Typography → Migrate Styles.
/// </summary>
public static class TypographyStylesMigration
{
    private const string ConfigPath = "Assets/Resources/TypographyConfig.asset";
    private const string MainScenePath = "Assets/Scenes/Game.unity";
    private const string TagClassIdentifier = "Assembly-CSharp::TypeRoleTag";

    private const string FontBlackItalic = "Assets/Fonts/Montserrat-BlackItalic SDF.asset";
    private const string FontBold = "Assets/Fonts/Montserrat-Bold SDF.asset";
    private const string FontSemiBold = "Assets/Fonts/Montserrat-SemiBold SDF.asset";

    // Индексы legacy enum TypeRole: Title, Secondary, Cta, DeathScore, Button, Body, LevelUpTitle.
    // Ни одно значение не усредняется: Title = BlackItalic (DeathTitle), LevelUpTitle = Bold, остальные = SemiBold.
    private static readonly string[] LegacyRoleToStyleId =
    {
        TypographyStyles.Title,
        TypographyStyles.Secondary,
        TypographyStyles.Cta,
        TypographyStyles.DeathScore,
        TypographyStyles.Button,
        TypographyStyles.Body,
        TypographyStyles.LevelUpTitle,
    };

    [MenuItem("AstroDrift/Typography/Migrate Styles")]
    public static void Migrate()
    {
        var log = new StringBuilder();

        var cfg = AssetDatabase.LoadAssetAtPath<TypographyConfig>(ConfigPath);
        if (cfg == null)
        {
            Debug.LogError($"[TypographyMigration] Не найден конфиг {ConfigPath} — миграция отменена.");
            return;
        }

        SeedStylesIfEmpty(cfg, log);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        int patched = PatchSerializedFiles(log);
        AssetDatabase.Refresh();

        Verify(log);

        Debug.Log($"[TypographyMigration] Готово. Изменённых файлов: {patched}.\n{log}");
    }

    // ————————————————————— засев стилей —————————————————————

    private static void SeedStylesIfEmpty(TypographyConfig cfg, StringBuilder log)
    {
        if (cfg.styles != null && cfg.styles.Length > 0)
        {
            log.AppendLine("Стили уже заданы — засев пропущен.");
            return;
        }

        var blackItalic = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(FontBlackItalic);
        var bold = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(FontBold);
        var semiBold = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(FontSemiBold);

        // Шрифты взяты из фактических нод (проверено по всем префабам и сцене Game):
        // Title = BlackItalic (DeathTitle), LevelUpTitle = Bold, все прочие стили = SemiBold.
        var seed = new (string id, string display, TMP_FontAsset font)[]
        {
            (TypographyStyles.Title,        "Заголовок (Death)",       blackItalic),
            (TypographyStyles.LevelUpTitle, "Заголовок левел-апа",     bold),
            (TypographyStyles.Secondary,    "Служебный текст",         semiBold),
            (TypographyStyles.Cta,          "CTA / кнопки",            semiBold),
            (TypographyStyles.Button,       "Кнопка",                  semiBold),
            (TypographyStyles.Body,         "Основной текст карточки", semiBold),
            (TypographyStyles.DeathScore,   "Крупные цифры (Death)",   semiBold),
        };

        var so = new SerializedObject(cfg);
        var styles = so.FindProperty(TypographyConfigFields.Styles);
        styles.arraySize = seed.Length;
        for (int i = 0; i < seed.Length; i++)
        {
            var el = styles.GetArrayElementAtIndex(i);
            el.FindPropertyRelative(TypographyConfigFields.Id).stringValue = seed[i].id;
            el.FindPropertyRelative(TypographyConfigFields.DisplayName).stringValue = seed[i].display;
            el.FindPropertyRelative(TypographyConfigFields.Font).objectReferenceValue = seed[i].font;
            el.FindPropertyRelative(TypographyConfigFields.FontStyle).intValue = (int)FontStyles.Normal;
            el.FindPropertyRelative(TypographyConfigFields.ApplyFontStyle).boolValue = false;
            el.FindPropertyRelative(TypographyConfigFields.LocaleFonts).arraySize = 0;
            if (seed[i].font == null)
                log.AppendLine($"ВНИМАНИЕ: шрифт для стиля '{seed[i].id}' не найден — будет fallback.");
        }
        so.ApplyModifiedPropertiesWithoutUndo();
        EditorUtility.SetDirty(cfg);
        log.AppendLine($"Засеяно стилей: {seed.Length}.");
    }

    // ————————————————————— правка сериализованных данных —————————————————————

    private static readonly Regex RoleLine = new Regex(@"^([ \t]*)role:[ \t]*(\d+)[ \t]*$", RegexOptions.Compiled);

    private static int PatchSerializedFiles(StringBuilder log)
    {
        var paths = new List<string>();
        foreach (var guid in AssetDatabase.FindAssets("t:Prefab"))
        {
            var p = AssetDatabase.GUIDToAssetPath(guid);
            if (p.StartsWith("Assets/") && p.EndsWith(".prefab")) paths.Add(p);
        }
        foreach (var guid in AssetDatabase.FindAssets("t:Scene"))
        {
            var p = AssetDatabase.GUIDToAssetPath(guid);
            if (p.StartsWith("Assets/") && p.EndsWith(".unity")) paths.Add(p);
        }

        int patchedFiles = 0;
        foreach (var path in paths)
        {
            string text;
            try { text = File.ReadAllText(path); }
            catch (IOException e) { log.AppendLine($"ПРОПУСК {path}: {e.Message}"); continue; }
            if (text.IndexOf(TagClassIdentifier, System.StringComparison.Ordinal) < 0) continue;

            if (!TryPatchSceneGuard(path, log)) continue;

            var result = PatchText(text, path, log);
            if (!result.Changed) continue;

            // Для сцены, открытой в редакторе, сначала сбрасываем from-disk состояние:
            // Unity не заметит правку файла, который держит в памяти.
            if (path.EndsWith(".unity") && SceneManager.GetActiveScene().path == path)
                EditorSceneManager.OpenScene(path, OpenSceneMode.Single); // reload с диска

            File.WriteAllText(path, result.Text);
            patchedFiles++;
        }
        return patchedFiles;
    }

    /// <summary>Сцену правим на диске только когда в ней нет несохранённых правок владельца.</summary>
    private static bool TryPatchSceneGuard(string path, StringBuilder log)
    {
        if (!path.EndsWith(".unity")) return true;
        var active = SceneManager.GetActiveScene();
        if (active.path != path || !active.isDirty) return true;
        log.AppendLine($"ПРОПУСК {path}: в сцене есть несохранённые правки — сохраните сцену и повторите миграцию.");
        return false;
    }

    private static (bool Changed, string Text) PatchText(string text, string path, StringBuilder log)
    {
        var lines = text.Replace("\r\n", "\n").Split('\n');
        bool inTagBlock = false;
        bool changed = false;

        for (int i = 0; i < lines.Length; i++)
        {
            var line = lines[i];

            if (line.StartsWith("--- ", System.StringComparison.Ordinal))
            {
                inTagBlock = false;
                continue;
            }
            if (line.IndexOf(TagClassIdentifier, System.StringComparison.Ordinal) >= 0)
            {
                inTagBlock = true; // строка m_EditorClassIdentifier: дальше идут поля компонента
                continue;
            }
            if (!inTagBlock) continue;

            var m = RoleLine.Match(line);
            if (!m.Success) continue;

            int legacyIndex = int.Parse(m.Groups[2].Value);
            if (legacyIndex < 0 || legacyIndex >= LegacyRoleToStyleId.Length)
            {
                log.AppendLine($"ВНИМАНИЕ {path} (строка {i + 1}): неизвестный role={legacyIndex}, оставлен без изменений.");
                continue;
            }

            var styleId = LegacyRoleToStyleId[legacyIndex];
            lines[i] = $"{m.Groups[1].Value}styleId: {styleId}";
            changed = true;
            inTagBlock = false;
            log.AppendLine($"{path}: role={legacyIndex} → styleId={styleId}");
        }

        return (changed, changed ? string.Join("\n", lines) : text);
    }

    // ————————————————————— проверка —————————————————————

    /// <summary>
    /// Проверяет, что после миграции каждая нода осталась на СВОЁМ шрифте
    /// (шрифт стиля совпадает с шрифтом ноды) и что нет тегов с пустым styleId.
    /// </summary>
    private static void Verify(StringBuilder log)
    {
        int checkedTags = 0, mismatches = 0;

        foreach (var guid in AssetDatabase.FindAssets("t:Prefab"))
        {
            var path = AssetDatabase.GUIDToAssetPath(guid);
            if (!path.StartsWith("Assets/")) continue;
            var root = AssetDatabase.LoadAssetAtPath<GameObject>(path);
            if (root == null) continue;
            CheckTags(root.GetComponentsInChildren<TypeRoleTag>(true), path, ref checkedTags, ref mismatches, log);
        }

        var previous = SceneManager.GetActiveScene();
        var scene = EditorSceneManager.OpenScene(MainScenePath, OpenSceneMode.Single);
        foreach (var root in scene.GetRootGameObjects())
            CheckTags(root.GetComponentsInChildren<TypeRoleTag>(true), MainScenePath, ref checkedTags, ref mismatches, log);
        if (previous.IsValid() && previous.path != MainScenePath)
            EditorSceneManager.OpenScene(previous.path, OpenSceneMode.Single);

        log.AppendLine(mismatches == 0
            ? $"Проверка: {checkedTags} тегов, расхождений шрифтов нет."
            : $"ПРОВЕРКА: {checkedTags} тегов, РАСХОЖДЕНИЙ: {mismatches} (см. выше).");
    }

    private static void CheckTags(TypeRoleTag[] tags, string path, ref int checkedTags, ref int mismatches, StringBuilder log)
    {
        var cfg = AssetDatabase.LoadAssetAtPath<TypographyConfig>(ConfigPath);
        foreach (var tag in tags)
        {
            checkedTags++;
            if (string.IsNullOrEmpty(tag.styleId))
            {
                mismatches++;
                log.AppendLine($"ПРОВЕРКА {path} :: {tag.gameObject.name}: styleId пуст (тег бездействует).");
                continue;
            }
            var style = cfg.GetStyle(tag.styleId);
            if (style == null)
            {
                mismatches++;
                log.AppendLine($"ПРОВЕРКА {path} :: {tag.gameObject.name}: стиля '{tag.styleId}' нет в конфиге.");
                continue;
            }
            var tmp = tag.GetComponent<TextMeshProUGUI>();
            if (tmp != null && style.font != null && tmp.font != style.font)
            {
                mismatches++;
                log.AppendLine($"ПРОВЕРКА {path} :: {tag.gameObject.name}: шрифт ноды {tmp.font.name} ≠ стиль {style.font.name}");
            }
        }
    }
}
#endif
