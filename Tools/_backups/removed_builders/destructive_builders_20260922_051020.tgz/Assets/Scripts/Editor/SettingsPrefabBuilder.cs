#if UNITY_EDITOR
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.Localization.Components;
using UnityEngine.UI;

/// <summary>
/// Редакторная утилита: собирает префаб экрана настроек (кнопка «НАСТРОЙКИ» в меню).
/// Внешние спрайты — ТОЛЬКО из контейнера PrefabBuilderSprites: settingsIcon (иконка экрана,
/// fallback для иконок строк) и buttonBg (кнопка BACK). Необязательные sfxIcon/musicIcon/resetIcon:
/// пусто — берётся settingsIcon, билдер не падает (в отличие от обязательных полей меню/левел-апа).
///   Assets/Prefabs/Menu/SettingsPanel.prefab — экран целиком (инстанс в StartPanel сцены Game)
/// Строит всё с нуля (нулевая зависимость от сцены) и перезаписывает ассет — повторный прогон
/// даёт тот же результат.
/// Меню: AstroDrift → Build Settings Prefab. После сборки — AstroDrift → Setup Scene UI.
/// </summary>
public static class SettingsPrefabBuilder
{
    private const string Folder = "Assets/Prefabs/Menu";
    private const string PanelPath = Folder + "/SettingsPanel.prefab";

    // Раскладка (референс 1080×1920, якоря/пивоты — как у остальных префабов меню)
    private const float PanelW = 1080f, PanelH = 1920f;
    private const float BoxW = 900f, BoxH = 820f, BoxY = 20f;
    private const float RowW = 840f, RowH = 200f;
    private const float Row1Y = -60f, Row2Y = -290f;   // от верхней кромки бокса
    private const float ResetY = -540f;                // от верхней кромки бокса

    [MenuItem("AstroDrift/Build Settings Prefab")]
    public static void BuildAll()
    {
        var log = new System.Text.StringBuilder();

        var cfg = PrefabBuilderAssets.LoadContainer<TypographyConfig>("Assets/Resources/TypographyConfig.asset", "SettingsPrefabBuilder");
        if (cfg == null) return;
        if (cfg.ResolveFont(TypographyStyles.Cta, null) == null) log.Append("ВНИМАНИЕ: TypographyConfig пуст (шрифт — fallback); ");

        var src = PrefabBuilderAssets.LoadContainer<PrefabBuilderSprites>(PrefabBuilderAssets.SpritesContainerPath, "SettingsPrefabBuilder",
            "Создайте: ПКМ в Project → Create → AstroDrift → Prefab Builder Sprites (см. поля контейнера).");
        if (src == null) return;

        // Обязательны только настройки-иконка и фон кнопки: остальные спрайты имеют fallback.
        if (!PrefabBuilderAssets.RequireAll(src, "SettingsPrefabBuilder",
                PrefabBuilderAssets.Field(src.settingsIcon, nameof(src.settingsIcon)),
                PrefabBuilderAssets.Field(src.buttonBg, nameof(src.buttonBg)),
                PrefabBuilderAssets.Field(src.barSprite, nameof(src.barSprite)))) return;

        Sprite sfxIcon = src.sfxIcon != null ? src.sfxIcon : src.settingsIcon;
        Sprite musicIcon = src.musicIcon != null ? src.musicIcon : src.settingsIcon;
        Sprite resetIcon = src.resetIcon != null ? src.resetIcon : src.settingsIcon;
        if (src.sfxIcon == null || src.musicIcon == null || src.resetIcon == null)
            log.Append("sfxIcon/musicIcon/resetIcon пусты → fallback на settingsIcon; ");

        EnsureFolders();
        BuildPanel(cfg, src, sfxIcon, musicIcon, resetIcon);
        log.Append("SettingsPanel OK");

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("AstroDrift SettingsPrefab: " + log);
    }

    // ————————————— Экран целиком (1080×1920) —————————————

    private static void BuildPanel(TypographyConfig cfg, PrefabBuilderSprites src,
                                   Sprite sfxIcon, Sprite musicIcon, Sprite resetIcon)
    {
        var root = new GameObject("SettingsPanel", typeof(RectTransform), typeof(Image), typeof(CanvasGroup));
        var rt = root.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
        rt.sizeDelta = new Vector2(PanelW, PanelH);

        // Затемнение: логотип и меню остаются видны под экраном (логотип НЕ переезжает).
        var img = root.GetComponent<Image>();
        img.color = Palette.UiOverlay;
        img.raycastTarget = true; // перехватывает тапы по Btn_TapToPlay под экраном

        // §8 проекта: скрытый экран неактивен + alpha 0 + raycasts off
        var cg = root.GetComponent<CanvasGroup>();
        cg.alpha = 0f; cg.blocksRaycasts = false; cg.interactable = false;

        // ——— Иконка настроек (первый слой каскада) ———
        var iconGo = NewRect(root.transform, "SettingsIcon");
        SetRect(iconGo, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, 590f), new Vector2(150f, 150f));
        var iconImg = iconGo.gameObject.AddComponent<Image>();
        iconImg.sprite = src.settingsIcon;
        iconImg.preserveAspect = true;
        iconImg.raycastTarget = false;
        iconGo.gameObject.AddComponent<CanvasGroup>().alpha = 1f;

        // ——— Заголовок (settings_title) ———
        var title = NewTmp(root.transform, "SettingsTitle", "НАСТРОЙКИ",
            FontOf(cfg, TypographyStyles.Cta), 56f, Palette.ScoreText, TextAlignmentOptions.Center);
        SetRect(title.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, 440f), new Vector2(900f, 80f));
        title.characterSpacing = 6f;
        AddLocalized(title, "settings_title", TypographyStyles.Cta);

        // ——— Бокс настроек (та же визуальная семья, что UnlockTreePanel: Image цвета UiPanel) ———
        var boxGo = NewRect(root.transform, "SettingsBox");
        SetRect(boxGo, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, BoxY), new Vector2(BoxW, BoxH));
        var boxImg = boxGo.gameObject.AddComponent<Image>();
        boxImg.color = Palette.UiPanel;
        boxImg.raycastTarget = true;
        boxGo.gameObject.AddComponent<CanvasGroup>().alpha = 1f;

        // Строка 1 — ЗВУКИ ИГРЫ
        var sfxRow = BuildSliderRow(boxGo, cfg, "SfxRow", "SfxSlider", "SfxValue",
            sfxIcon, "settings_sfx", Row1Y, Palette.XpBar);
        // Строка 2 — МУЗЫКА
        var musicRow = BuildSliderRow(boxGo, cfg, "MusicRow", "MusicSlider", "MusicValue",
            musicIcon, "settings_music", Row2Y, Palette.UiAccent);

        // ——— Красная кнопка сброса прогресса (геометрия Btn_Reroll, тинт WarningRed) ———
        var resetGo = NewRect(boxGo, "Btn_Reset");
        SetRect(resetGo, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, ResetY), new Vector2(560f, 200f));
        var resetImg = resetGo.gameObject.AddComponent<Image>();
        resetImg.sprite = src.rerollBg;
        resetImg.type = Image.Type.Simple;
        resetImg.preserveAspect = true;
        resetImg.color = Palette.WarningRed;   // красный = деструктивное действие
        resetImg.raycastTarget = true;
        var resetBtn = resetGo.gameObject.AddComponent<Button>();
        resetBtn.targetGraphic = resetImg;

        var resetIconRt = NewRect(resetGo, "ResetIcon");
        SetRect(resetIconRt, new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(48f, 0f), new Vector2(64f, 64f));
        var resetIconImg = resetIconRt.gameObject.AddComponent<Image>();
        resetIconImg.sprite = resetIcon;
        resetIconImg.preserveAspect = true;
        resetIconImg.raycastTarget = false;

        // Ключ меняется рантаймом на settings_reset_confirm (двухшаговое подтверждение в SettingsScreen)
        var resetText = NewTmp(resetGo, "ResetText", "СБРОСИТЬ ПРОГРЕСС",
            FontOf(cfg, TypographyStyles.Cta), 32f, Palette.ScoreText, TextAlignmentOptions.Center);
        SetRect(resetText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(24f, 0f), new Vector2(480f, 60f));
        AddLocalized(resetText, "settings_reset_progress", TypographyStyles.Cta);

        // ——— BACK — нижний левый угол экрана (арт нижних кнопок меню) ———
        var backGo = NewRect(root.transform, "Btn_Back");
        SetRect(backGo, new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(56f, 72f), new Vector2(232f, 120f));
        var backImg = backGo.gameObject.AddComponent<Image>();
        backImg.sprite = src.buttonBg;
        backImg.type = Image.Type.Simple;
        backImg.preserveAspect = true;
        backImg.raycastTarget = true;
        var backBtn = backGo.gameObject.AddComponent<Button>();
        backBtn.targetGraphic = backImg;

        var backText = NewTmp(backGo, "BackText", "НАЗАД",
            FontOf(cfg, TypographyStyles.Cta), 26f, Palette.ScoreText, TextAlignmentOptions.Center);
        SetRect(backText.rectTransform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(200f, 50f));
        AddLocalized(backText, "settings_back", TypographyStyles.Cta);

        // ——— Ссылки компонента (сценовые menuRoot/targetScreen проставит SceneSetup) ———
        var settings = root.AddComponent<SettingsScreen>();
        var so = new SerializedObject(settings);
        so.FindProperty("canvasGroup").objectReferenceValue = cg;
        so.FindProperty("sfxSlider").objectReferenceValue = sfxRow.slider;
        so.FindProperty("sfxValueText").objectReferenceValue = sfxRow.value;
        so.FindProperty("musicSlider").objectReferenceValue = musicRow.slider;
        so.FindProperty("musicValueText").objectReferenceValue = musicRow.value;
        so.FindProperty("backBtn").objectReferenceValue = backBtn;
        so.FindProperty("resetBtn").objectReferenceValue = resetBtn;
        so.FindProperty("resetLabel").objectReferenceValue = resetText;
        so.FindProperty("cascadeIcon").objectReferenceValue = (RectTransform)iconGo;
        so.FindProperty("cascadeTitle").objectReferenceValue = title.rectTransform;
        so.FindProperty("cascadeBox").objectReferenceValue = (RectTransform)boxGo;
        so.FindProperty("cascadeBack").objectReferenceValue = (RectTransform)backGo;
        so.ApplyModifiedPropertiesWithoutUndo();

        PrefabUtility.SaveAsPrefabAsset(root, PanelPath);
        Object.DestroyImmediate(root);
    }

    // ————————————— Строка слайдера —————————————

    private struct RowRefs { public Slider slider; public TextMeshProUGUI value; }

    /// <summary>Строка: иконка слева, подпись, справа «NN%», под подписью — слайдер.</summary>
    private static RowRefs BuildSliderRow(RectTransform box, TypographyConfig cfg, string rowName,
                                          string sliderName, string valueName, Sprite icon,
                                          string locKey, float yFromTop, Color fillColor)
    {
        var row = NewRect(box, rowName);
        SetRect(row, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, yFromTop), new Vector2(RowW, RowH));

        var iconRt = NewRect(row, "Icon");
        SetRect(iconRt, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(20f, -10f), new Vector2(64f, 64f));
        var iconImg = iconRt.gameObject.AddComponent<Image>();
        iconImg.sprite = icon;
        iconImg.preserveAspect = true;
        iconImg.raycastTarget = false;

        var label = NewTmp(row, "Label", "", FontOf(cfg, TypographyStyles.Cta), 34f,
            Palette.ScoreText, TextAlignmentOptions.Left);
        SetRect(label.rectTransform, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(104f, -10f), new Vector2(520f, 56f));
        AddLocalized(label, locKey, TypographyStyles.Cta);

        var value = NewTmp(row, valueName, "100%", FontOf(cfg, TypographyStyles.Secondary), 34f,
            Palette.SecondaryText, TextAlignmentOptions.Right);
        SetRect(value.rectTransform, new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-20f, -10f), new Vector2(200f, 56f));

        var slider = BuildSlider(row, sliderName, fillColor);
        return new RowRefs { slider = slider, value = value };
    }

    /// <summary>Слайдер Unity: фон + заливка + ручка. Событие onValueChanged вешает SettingsScreen.OnEnable.</summary>
    private static Slider BuildSlider(RectTransform parent, string name, Color fillColor)
    {
        var go = NewRect(parent, name);
        SetRect(go, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 20f), new Vector2(760f, 48f));

        var bg = NewRect(go, "Background");
        bg.anchorMin = new Vector2(0f, 0.25f);
        bg.anchorMax = new Vector2(1f, 0.75f);
        bg.offsetMin = Vector2.zero; bg.offsetMax = Vector2.zero;
        var bgImg = bg.gameObject.AddComponent<Image>();
        bgImg.color = Palette.UiPanelFrame;
        bgImg.raycastTarget = true; // тапать по дорожке удобнее, чем только по ручке

        var fillArea = NewRect(go, "Fill Area");
        fillArea.anchorMin = new Vector2(0f, 0.25f);
        fillArea.anchorMax = new Vector2(1f, 0.75f);
        fillArea.offsetMin = new Vector2(8f, 0f);
        fillArea.offsetMax = new Vector2(-8f, 0f);

        var fill = NewRect(fillArea, "Fill");
        fill.anchorMin = Vector2.zero;
        fill.anchorMax = Vector2.one;
        fill.offsetMin = Vector2.zero; fill.offsetMax = Vector2.zero;
        var fillImg = fill.gameObject.AddComponent<Image>();
        fillImg.color = fillColor;
        fillImg.raycastTarget = false;

        var handleArea = NewRect(go, "Handle Slide Area");
        handleArea.anchorMin = new Vector2(0f, 0f);
        handleArea.anchorMax = new Vector2(1f, 1f);
        handleArea.offsetMin = new Vector2(8f, 0f);
        handleArea.offsetMax = new Vector2(-8f, 0f);

        var handle = NewRect(handleArea, "Handle");
        handle.sizeDelta = new Vector2(40f, 40f);
        var handleImg = handle.gameObject.AddComponent<Image>();
        handleImg.color = Palette.ScoreText;
        handleImg.raycastTarget = true;

        var slider = go.gameObject.AddComponent<Slider>();
        slider.direction = Slider.Direction.LeftToRight;
        slider.minValue = 0f;
        slider.maxValue = 1f;
        slider.wholeNumbers = false;
        slider.fillRect = fill;
        slider.handleRect = handle;
        slider.targetGraphic = handleImg;
        slider.value = 1f;
        return slider;
    }

    // ————————————— локализация / хелперы —————————————

    private static void AddLocalized(TextMeshProUGUI tmp, string key, string styleId)
    {
        var lse = tmp.gameObject.AddComponent<LocalizeStringEvent>();
        lse.StringReference.TableReference = "GameTexts";
        lse.StringReference.TableEntryReference = key;
        BindTmpText(lse, tmp);
        AddRole(tmp, styleId);
    }

    private static void BindTmpText(LocalizeStringEvent lse, TextMeshProUGUI tmp)
    {
        var setter = tmp.GetType().GetProperty("text").GetSetMethod();
        var handler = System.Delegate.CreateDelegate(typeof(UnityEngine.Events.UnityAction<string>), tmp, setter)
            as UnityEngine.Events.UnityAction<string>;
        UnityEditor.Events.UnityEventTools.AddPersistentListener(lse.OnUpdateString, handler);
        lse.OnUpdateString.SetPersistentListenerState(0, UnityEngine.Events.UnityEventCallState.EditorAndRuntime);
    }

    private static TMP_FontAsset FontOf(TypographyConfig cfg, string styleId) => cfg.ResolveFont(styleId, null);

    private static void AddRole(TextMeshProUGUI tmp, string styleId)
    {
        var tag = tmp.gameObject.AddComponent<TypeRoleTag>();
        var so = new SerializedObject(tag);
        so.FindProperty("styleId").stringValue = styleId;
        so.ApplyModifiedPropertiesWithoutUndo();
    }

    private static void EnsureFolders()
    {
        if (!AssetDatabase.IsValidFolder("Assets/Prefabs")) AssetDatabase.CreateFolder("Assets", "Prefabs");
        if (!AssetDatabase.IsValidFolder(Folder)) AssetDatabase.CreateFolder("Assets/Prefabs", "Menu");
    }

    private static RectTransform NewRect(Transform parent, string name)
    {
        var go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        return go.GetComponent<RectTransform>();
    }

    private static void SetRect(RectTransform rt, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size)
    {
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.pivot = pivot;
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
    }

    private static TextMeshProUGUI NewTmp(Transform parent, string name, string text, TMP_FontAsset font,
                                          float size, Color color, TextAlignmentOptions align)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
        go.transform.SetParent(parent, false);
        var tmp = go.GetComponent<TextMeshProUGUI>();
        tmp.text = text;
        if (font != null) tmp.font = font;
        tmp.fontSize = size;
        tmp.color = color;
        tmp.alignment = align;
        tmp.textWrappingMode = TextWrappingModes.NoWrap;
        tmp.raycastTarget = false;
        return tmp;
    }
}
#endif
